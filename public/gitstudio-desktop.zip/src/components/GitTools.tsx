import React, { useState } from 'react';
import {
  ArrowDownToLine,
  BarChart3,
  Play,
  FileText,
  CheckSquare,
  AlertTriangle,
  FolderOpen,
  ShieldAlert,
  Terminal,
  Download,
  Copy,
  Check,
  ExternalLink,
} from 'lucide-react';
import { GitReport } from '../types';

interface GitToolsProps {
  onOpenReportModal: (report: GitReport) => void;
  onOpenTroubleshoot: (errorSnippet: string) => void;
  onOpenTerminal: (command?: string) => void;
}

export const GitTools: React.FC<GitToolsProps> = ({
  onOpenReportModal,
  onOpenTroubleshoot,
  onOpenTerminal,
}) => {
  // Pull All State
  const [pullScope, setPullScope] = useState<'all' | 'gestaltce' | 'trib' | 'rick'>('all');
  const [isPullRunning, setIsPullRunning] = useState(false);
  const [pullStatus, setPullStatus] = useState<'idle' | 'running' | 'done'>('idle');
  const [hasCopiedPs, setHasCopiedPs] = useState(false);
  const [pullLog, setPullLog] = useState<string>(
    [
      '==============================================================',
      '        GitStudio Desktop — Batch Git Synchronization         ',
      '==============================================================',
      'Target Directories:',
      '  - GestaltCE:              C:\\git',
      '  - Tribernachi-Foundation:  C:\\git\\trib',
      '  - rickpeters112233:       C:\\git\\rick',
      'Reports Path:               C:\\git\\reports',
      '==============================================================',
      '',
      'Ready to synchronize repositories.',
      'Click "Run Git Pull All" below to execute batch pull.',
      'You can also run .\\pull-all-workspaces.bat directly in Windows.',
    ].join('\n')
  );
  const [lastPullReport, setLastPullReport] = useState<GitReport | null>(null);

  // Daily Report State
  const [reportPeriod, setReportPeriod] = useState<'daily' | '3days' | 'weekly'>('daily');
  const [isReportRunning, setIsReportRunning] = useState(false);
  const [reportStatus, setReportStatus] = useState<'idle' | 'running' | 'done'>('idle');
  const [reportLog, setReportLog] = useState<string>('');
  const [lastDailyReport, setLastDailyReport] = useState<GitReport | null>(null);

  // Execute Git Pull All with real-time SSE streaming
  const runGitPullAll = async () => {
    setIsPullRunning(true);
    setPullStatus('running');
    setPullLog(`[INITIATING BATCH PULL] Connecting to batch pull engine (Scope: ${pullScope.toUpperCase()})...\n`);

    try {
      const res = await fetch(`/api/batch/pull-all/stream?scope=${pullScope}`);
      if (!res.ok) {
        const errText = await res.text();
        throw new Error(`Server returned HTTP ${res.status}: ${errText.slice(0, 100)}`);
      }

      if (res.body) {
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const blocks = buffer.split('\n\n');
          buffer = blocks.pop() || '';

          for (const block of blocks) {
            const trimmed = block.trim();
            if (trimmed.startsWith('data: ')) {
              try {
                const payload = JSON.parse(trimmed.slice(6));
                if (payload.type === 'start') {
                  setPullLog(`[INITIATING BATCH PULL] ${payload.message}\nTotal repositories: ${payload.total}\n\n`);
                } else if (payload.type === 'progress') {
                  setPullLog((prev) => prev + payload.line + '\n');
                } else if (payload.type === 'complete') {
                  if (payload.report) {
                    setPullLog(payload.report.log);
                    setLastPullReport(payload.report);
                  }
                } else if (payload.type === 'error') {
                  setPullLog((prev) => prev + `\n[ERROR]: ${payload.message}\n`);
                }
              } catch (e) {
                // ignore SSE parse chunk
              }
            }
          }
        }
      } else {
        // Fallback for non-streaming environments
        const fallbackRes = await fetch('/api/batch/pull-all', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ scope: pullScope }),
        });
        const data = await fallbackRes.json();
        if (data.report) {
          setPullLog(data.report.log);
          setLastPullReport(data.report);
        }
      }
      setPullStatus('done');
    } catch (err: any) {
      setPullLog((prev) => prev + `\n[ERROR]: ${err.message}`);
      setPullStatus('done');
    } finally {
      setIsPullRunning(false);
    }
  };

  // Execute Daily Report
  const runDailyReport = async () => {
    setIsReportRunning(true);
    setReportStatus('running');
    setReportLog(`Fetching commits, PRs, and issues for period: ${reportPeriod}...\n`);

    try {
      const res = await fetch('/api/batch/daily-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ period: reportPeriod }),
      });
      const data = await res.json();
      if (data.report) {
        setReportLog(
          [
            `GitHub Daily Report generated for GestaltCE, Tribernachi-Foundation, rickpeters112233`,
            `Coverage: ${data.report.summary.total} repositories`,
            `Period: ${reportPeriod.toUpperCase()}`,
            '',
            data.report.log,
            '',
            `Report file saved: ${data.report.path}`,
          ].join('\n')
        );
        setLastDailyReport(data.report);
      }
      setReportStatus('done');
    } catch (err: any) {
      setReportLog((prev) => prev + `\n[ERROR]: ${err.message}`);
      setReportStatus('done');
    } finally {
      setIsReportRunning(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0b0f19] text-slate-200 overflow-hidden select-none">
      {/* Header Bar matching screenshot: "Git Tools | Pull All + Daily Report — each runs independently" */}
      <div className="px-6 py-3 border-b border-slate-800/80 bg-slate-950/70 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-5 h-5 rounded-full border border-sky-400 flex items-center justify-center text-sky-400 text-xs font-bold">
            ⬡
          </div>
          <h1 className="text-sm font-semibold text-slate-100 font-mono tracking-tight">
            Git Tools
          </h1>
          <span className="text-xs text-slate-400 font-mono">
            Pull All + Daily Report — each runs independently
          </span>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
          <span>Reports Path:</span>
          <span className="text-amber-400">C:\git\reports\</span>
        </div>
      </div>

      {/* Main Dual Cards Split Container */}
      <div className="flex-1 p-4 grid grid-cols-1 lg:grid-cols-2 gap-4 overflow-hidden">
        {/* CARD 1: Git Pull All (Left Card) */}
        <div className="flex flex-col h-full rounded-lg border border-slate-800/90 bg-[#0d1322] overflow-hidden">
          {/* Card Header */}
          <div className="p-4 border-b border-slate-800/80 space-y-2">
            <div className="flex items-center gap-2 text-sky-400">
              <ArrowDownToLine className="w-5 h-5" />
              <h2 className="text-base font-semibold text-slate-100 tracking-tight">
                Git Pull All
              </h2>
            </div>
            <p className="text-xs text-slate-400">
              Pulls every repo in C:\git (GestaltCE), C:\git\trib, C:\git\rick • clones new repos • HTML report saved to reports\
            </p>

            {/* Action Bar */}
            <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <button
                  onClick={runGitPullAll}
                  disabled={isPullRunning}
                  className="flex items-center gap-2 px-4 py-2 rounded bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs shadow-sm transition-colors disabled:opacity-50"
                >
                  <Play className={`w-3.5 h-3.5 fill-current ${isPullRunning ? 'animate-spin' : ''}`} />
                  <span>Run Git Pull All</span>
                </button>

                {/* Scope selector */}
                <select
                  value={pullScope}
                  onChange={(e: any) => setPullScope(e.target.value)}
                  className="bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-slate-200 font-mono focus:outline-none cursor-pointer"
                >
                  <option value="all">All (c:\git, trib, rick)</option>
                  <option value="gestaltce">GestaltCE (c:\git)</option>
                  <option value="trib">Tribernachi (c:\git\trib)</option>
                  <option value="rick">Rick Peters (c:\git\rick)</option>
                </select>

                {pullStatus === 'done' && (
                  <span className="flex items-center gap-1 text-xs text-emerald-400 font-mono font-medium">
                    <CheckSquare className="w-3.5 h-3.5" /> Done
                  </span>
                )}
                {isPullRunning && (
                  <span className="text-xs text-amber-400 font-mono animate-pulse">
                    Pulling repos...
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2">
                <a
                  href="/pull-all-workspaces.bat"
                  download="pull-all-workspaces.bat"
                  title="Download pull-all-workspaces.bat directly into C:\git\gitstudio"
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded border border-emerald-700/80 bg-emerald-950/50 hover:bg-emerald-900/50 text-emerald-300 text-xs font-medium transition-colors"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Download pull-all.bat</span>
                </a>

                <button
                  onClick={() => {
                    navigator.clipboard.writeText('powershell -ExecutionPolicy Bypass -File .\\pull-all-workspaces.ps1');
                    setHasCopiedPs(true);
                    setTimeout(() => setHasCopiedPs(false), 2000);
                  }}
                  title="Copy PowerShell batch pull command for Windows terminal"
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs transition-colors"
                >
                  {hasCopiedPs ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                  <span>{hasCopiedPs ? 'Copied PS Cmd' : 'Copy PS Cmd'}</span>
                </button>

                {lastPullReport && (
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onOpenReportModal(lastPullReport)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded border border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs transition-colors"
                    >
                      <FileText className="w-3.5 h-3.5 text-sky-400" />
                      <span>View HTML</span>
                    </button>
                    <a
                      href={`/api/reports/${lastPullReport.id}/download`}
                      download
                      className="flex items-center gap-1 px-2.5 py-1.5 rounded border border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs transition-colors"
                      title="Download HTML report directly"
                    >
                      <Download className="w-3.5 h-3.5 text-emerald-400" />
                    </a>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Terminal Console Output Window */}
          <div className="flex-1 p-3 bg-[#080d1a] overflow-hidden flex flex-col">
            <div className="flex items-center justify-between pb-1.5 border-b border-slate-800/60 text-[11px] font-mono text-slate-500">
              <span>BATCH LOG OUTPUT</span>
              {pullLog.includes('fatal:') && (
                <button
                  onClick={() => onOpenTroubleshoot(pullLog)}
                  className="flex items-center gap-1 text-rose-400 hover:text-rose-300 font-semibold"
                >
                  <ShieldAlert className="w-3 h-3" /> Fix Failures with AI
                </button>
              )}
            </div>
            <pre className="flex-1 overflow-y-auto font-mono text-[11px] leading-relaxed text-slate-300 p-2 whitespace-pre select-text selection:bg-sky-900">
              {pullLog}
            </pre>
          </div>
        </div>

        {/* CARD 2: GitHub Daily Report (Right Card) */}
        <div className="flex flex-col h-full rounded-lg border border-slate-800/90 bg-[#0d1322] overflow-hidden">
          {/* Card Header */}
          <div className="p-4 border-b border-slate-800/80 space-y-2">
            <div className="flex items-center gap-2 text-amber-400">
              <BarChart3 className="w-5 h-5" />
              <h2 className="text-base font-semibold text-slate-100 tracking-tight">
                GitHub Daily Report
              </h2>
            </div>
            <p className="text-xs text-slate-400">
              Commits, PRs & issues across GestaltCE, Tribernachi & Rick Peters repos • HTML report saved to reports\
            </p>

            {/* Action Bar */}
            <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400">
                  <span>Period:</span>
                  <select
                    value={reportPeriod}
                    onChange={(e: any) => setReportPeriod(e.target.value)}
                    className="bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-slate-200 font-mono focus:outline-none cursor-pointer"
                  >
                    <option value="daily">daily</option>
                    <option value="3days">3 days</option>
                    <option value="weekly">weekly</option>
                  </select>
                </div>

                <button
                  onClick={runDailyReport}
                  disabled={isReportRunning}
                  className="flex items-center gap-2 px-4 py-2 rounded bg-amber-600 hover:bg-amber-500 text-slate-950 font-semibold text-xs shadow-sm transition-colors disabled:opacity-50"
                >
                  <Play className={`w-3.5 h-3.5 fill-current ${isReportRunning ? 'animate-spin' : ''}`} />
                  <span>Run Report</span>
                </button>

                <span className="text-xs text-slate-400 font-mono">
                  {reportStatus === 'done' ? (
                    <span className="text-emerald-400 flex items-center gap-1">
                      <CheckSquare className="w-3.5 h-3.5" /> Done
                    </span>
                  ) : isReportRunning ? (
                    <span className="text-amber-400 animate-pulse">Compiling...</span>
                  ) : (
                    'Ready'
                  )}
                </span>
              </div>

              <div className="flex items-center gap-2">
                {lastDailyReport && (
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onOpenReportModal(lastDailyReport)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded border border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs transition-colors"
                    >
                      <FileText className="w-3.5 h-3.5 text-amber-400" />
                      <span>View HTML</span>
                    </button>
                    <a
                      href={`/api/reports/${lastDailyReport.id}/download`}
                      download
                      className="flex items-center gap-1 px-2.5 py-1.5 rounded border border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs transition-colors"
                      title="Download HTML report directly"
                    >
                      <Download className="w-3.5 h-3.5 text-emerald-400" />
                    </a>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Terminal / Report Display Window */}
          <div className="flex-1 p-3 bg-[#080d1a] overflow-hidden flex flex-col">
            <div className="flex items-center justify-between pb-1.5 border-b border-slate-800/60 text-[11px] font-mono text-slate-500">
              <span>REPORT PREVIEW & TELEMETRY</span>
              {lastDailyReport && (
                <span className="text-amber-400">
                  {lastDailyReport.summary.total} repos analyzed
                </span>
              )}
            </div>

            <div className="flex-1 overflow-y-auto p-2 font-mono text-[11px] text-slate-300 space-y-3">
              {reportLog ? (
                <pre className="whitespace-pre-wrap leading-relaxed select-text selection:bg-amber-900/60">
                  {reportLog}
                </pre>
              ) : (
                <div className="p-8 text-center text-slate-500 space-y-2">
                  <BarChart3 className="w-8 h-8 mx-auto text-slate-700" />
                  <p>Click "Run Report" above to aggregate commits and pull requests.</p>
                  <p className="text-[10px] text-slate-600">
                    Reports will compile into HTML format and persist under reports\ directory.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
